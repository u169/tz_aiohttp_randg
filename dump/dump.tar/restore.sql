--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.5 (Debian 11.5-1.pgdg90+1)
-- Dumped by pg_dump version 11.5 (Debian 11.5-1.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE db;
--
-- Name: db; Type: DATABASE; Schema: -; Owner: user
--

CREATE DATABASE db WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8';


ALTER DATABASE db OWNER TO "user";

\connect db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: intarray; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS intarray WITH SCHEMA public;


--
-- Name: EXTENSION intarray; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION intarray IS 'functions, operators, and index support for 1-D arrays of integers';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: movie; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.movie (
    movie_id integer NOT NULL,
    title character varying,
    genres character varying
);


ALTER TABLE public.movie OWNER TO "user";

--
-- Name: movie_movie_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.movie_movie_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.movie_movie_id_seq OWNER TO "user";

--
-- Name: movie_movie_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.movie_movie_id_seq OWNED BY public.movie.movie_id;


--
-- Name: profile; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.profile (
    profile_id integer NOT NULL,
    username character varying,
    name character varying,
    sex character(1),
    address character varying,
    mail character varying
);


ALTER TABLE public.profile OWNER TO "user";

--
-- Name: profile_movie; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.profile_movie (
    profile_id integer NOT NULL,
    movie_id integer NOT NULL
);


ALTER TABLE public.profile_movie OWNER TO "user";

--
-- Name: profile_profile_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.profile_profile_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.profile_profile_id_seq OWNER TO "user";

--
-- Name: profile_profile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.profile_profile_id_seq OWNED BY public.profile.profile_id;


--
-- Name: movie movie_id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.movie ALTER COLUMN movie_id SET DEFAULT nextval('public.movie_movie_id_seq'::regclass);


--
-- Name: profile profile_id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.profile ALTER COLUMN profile_id SET DEFAULT nextval('public.profile_profile_id_seq'::regclass);


--
-- Data for Name: movie; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.movie (movie_id, title, genres) FROM stdin;
\.
COPY public.movie (movie_id, title, genres) FROM '$$PATH$$/2967.dat';

--
-- Data for Name: profile; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.profile (profile_id, username, name, sex, address, mail) FROM stdin;
\.
COPY public.profile (profile_id, username, name, sex, address, mail) FROM '$$PATH$$/2965.dat';

--
-- Data for Name: profile_movie; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.profile_movie (profile_id, movie_id) FROM stdin;
\.
COPY public.profile_movie (profile_id, movie_id) FROM '$$PATH$$/2968.dat';

--
-- Name: movie_movie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.movie_movie_id_seq', 50, true);


--
-- Name: profile_profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.profile_profile_id_seq', 10000, true);


--
-- Name: movie movie_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.movie
    ADD CONSTRAINT movie_pkey PRIMARY KEY (movie_id);


--
-- Name: profile_movie profile_movie_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.profile_movie
    ADD CONSTRAINT profile_movie_pkey PRIMARY KEY (profile_id, movie_id);


--
-- Name: profile profile_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.profile
    ADD CONSTRAINT profile_pkey PRIMARY KEY (profile_id);


--
-- Name: profile_movie profile_movie_movie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.profile_movie
    ADD CONSTRAINT profile_movie_movie_id_fkey FOREIGN KEY (movie_id) REFERENCES public.movie(movie_id) ON UPDATE CASCADE;


--
-- Name: profile_movie profile_movie_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.profile_movie
    ADD CONSTRAINT profile_movie_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profile(profile_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

